<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="/">XTRIMUM</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="<?php echo e(route('about')); ?>" class="nav-link">About</a></li>
            <li class="nav-item"><a href="<?php echo e(route('our_work')); ?>" class="nav-link">Work</a></li>
            <li class="nav-item"><a href="<?php echo e(route('contact')); ?>" class="nav-link">Contact</a></li>
        </ul>
    </div>
    </div>
  </nav><?php /**PATH C:\Users\ateke\OneDrive\Desktop\Xtrimum Solutions\Xtrimum Portfolio Laravel\xtrimum_portfolio\resources\views/components/header.blade.php ENDPATH**/ ?>