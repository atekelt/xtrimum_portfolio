@extends('layouts.app')


@section('content')

<section class="hero-wrap py-5" style="background-color: #000; color: #fff;">
    <div class="container">
      <div class="row justify-content-center text-center">
        <div class="col-md-8 ftco-animate">
          <h1 class="mb-3" style="font-weight: 600; font-size: 2.5rem;">Our Work</h1>
          <p class="breadcrumbs mb-0">
            <a href="/" style="color: #bbb;">Home <i class="ion-ios-arrow-forward"></i></a> 
            <span style="color: #bbb;"> / About Us</span>
          </p>
        </div>
      </div>
    </div>
  </section>

<section class="ftco-section ftco-intro">
    <div class="container">
        <div class="row justify-content-end">
            <div class="col-md-8">
                <h2>Coming Soon !!!</h2>
                
            </div>
        </div>
    </div>
</section>
@endsection